from odoo import api, fields, tools, models, _


class ApprovalConfiguration(models.Model):
    _name = 'approval.configuration'
    _description = "Approval Configuration"

    name = fields.Char(string="Approval", required=True)
    model_id = fields.Many2one(
        "ir.model",
        string="On Change Fields Trigger",
        help="Fields that trigger the onchange.",
    )
    # view_id = fields.Many2one(
    #     "ir.ui.view",
    #     # compute='get_views_related_to_model',
    #     string="Views",
    #     # domain="[('model', '=', model_id)]",
    #     help="Views that trigger.",
    # )
    view_ids = fields.Many2many('ir.ui.view', string='Views')

    updated_field = fields.Many2one(
        "ir.model.fields",
        compute='_compute_on_change_field_ids',
        readonly=False, store=True,
        string="Fields",
        domain="[('model_id', '=', model_id)]",
        help="Fields that trigger.",
    )
    updated_value = fields.Char('')

    approval_field_accept = fields.Many2one(
        "ir.model.fields",
        compute='_compute_on_change_field_ids',
        readonly=False, store=True,
        string="Fields",
        domain="[('model_id', '=', model_id)]",
        help="Fields that trigger.",
    )
    approval_field_accept_value = fields.Char('')

    approval_field_reject = fields.Many2one(
        "ir.model.fields",
        compute='_compute_on_change_field_ids',
        readonly=False, store=True,
        string="Fields",
        domain="[('model_id', '=', model_id)]",
        help="Fields that trigger.",
    )
    approval_field_reject_value = fields.Char('')
    approval_detail_ids = fields.One2many('approval.details', 'approval_config_id', string="Approval Details")


    # @api.onchange('model_id')
    # def _change_view(self):
    #     self.view_id = self.env['ir.ui.view'].search([('model', '=', self.model_id.model), ('type', '=', 'form')])

    @api.depends('model_id')
    def _view_ids(self):
        self.view_ids = self.env['ir.ui.view'].search([('model', '=', self.model_id.model)])


    def get_views_related_to_model(self):
        ir_model_data = self.env['ir.model.data']
        ir_ui_view = self.env['ir.ui.view']

        model_name = self.model_id.name
        model_data = ir_model_data.search([('model', '=', model_name)])

        views = ir_ui_view.browse([data.res_id for data in model_data if data.module == 'base'])

        # 'base' in data.module is used as an example; replace it with your module name if needed

        for view in views:
            print("View Name:", view.name)
            print("View ID:", view.id)
            print("View Type:", view.type)
            print("View Architecture:", view.arch)

        # You can also return the views instead of printing
        return views

    on_change_field_ids = fields.Many2one(
        "ir.model.fields",
        compute='_compute_on_change_field_ids',
        readonly=False, store=True,
        string="Fields",
        domain="[('model_id', '=', model_id)]",
        help="Fields that trigger.",
    )
    trigger = fields.Selection([
        ('on_change', 'Based on Form Modification'),
    ], string='Trigger', required=True)



    @api.depends('model_id', 'trigger')
    def _compute_on_change_field_ids(self):
        to_reset = self.filtered(lambda act: act.trigger != 'on_change')
        print('reset--->', to_reset)
        if to_reset:
            to_reset.on_change_field_ids = False
        print('qq------------>', (self - to_reset).filtered('on_change_field_ids'))
        for action in (self - to_reset).filtered('on_change_field_ids'):
            action.on_change_field_ids = action.on_change_field_ids.filtered(lambda field: field.model_id == action.model_id)

    @api.depends('model_id', 'trigger')
    def _compute_on_change_view_ids(self):
        to_reset = self.filtered(lambda act: act.trigger != 'on_change')
        if to_reset:
            to_reset.view_id = False
        for action in (self - to_reset).filtered('view_id'):
            action.view_id = action.view_id.filtered(lambda field: field.model == action.model_id)


# class ApprovalDetailsLine(models.Model):
#     _name = 'approval.details.line'
#     _description = "Approval Details"
#
#     approve_process_by = fields.Selection([('user', 'User'),
#                               ('group', 'Group'),], default='user', tracking=True)
#     level = fields.Integer(string="Approval Level")