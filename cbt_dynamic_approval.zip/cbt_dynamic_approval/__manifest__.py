# -*- coding: utf-8 -*-

{
    "name": "Dynamic Approval",
    "author": "Cybobits Technologies",
    "website": "https://www.Cybobits.com",
    "support": "support@Cybobits.com",
    "version": "16.0.1",
    "license": "OPL-1",
    "category": "Extra Tools",
    "summary": "Dynamic Approval",
    "description": """Dynamic Approval module is a base module for below modules.""",
    "depends": ["base"],
    "data": [
        'security/ir.model.access.csv',
        'view/approval_group.xml',
        'view/approval_user_group.xml',
        'view/approval_configuration.xml',
        'view/cbt_menu_views.xml',

    ],

    # 'assets': {
    #
    #     'web.assets_backend': [
    #         'cbt_dynamic_approval/static/src/js/bus_notification.js',
    #     ]
    #  },
    "auto_install": False,
    "installable": True,
    "application": True,
}
