from odoo import api, fields, tools, models, _


class ApprovalDetails(models.Model):
    _name = 'approval.details'
    _description = "Approval Details"

    name = fields.Char('Level')
    approve_process_by = fields.Selection([
        ('user', 'User'), ('group', 'Group'),
    ], string='Process By', index=True, copy=False, default='user', tracking=True)
    user_id = fields.Many2one('res.users', string="Users")
    group_id = fields.Many2one('approval.group', string="Groups")
    user_approvals = fields.Char('Approvals', compute='_get_user_approval')#
    sequence_level = fields.Integer('sequence')
    approval_config_id = fields.Many2one('approval.configuration', string="Approval Config")
    active = fields.Boolean(string="Status")

    @api.depends('user_id', 'group_id')
    def _get_user_approval(self):
        uapp = ""
        self.user_approvals = ""
        res = self.env['approval.user.group'].search([('group_id', '=', self.group_id.id)])
        if self.approve_process_by == 'user':
            self.user_approvals = self.user_id.name
        else:
            print('group-----------.')
            for rec in res.user_ids:
                print('name---->', rec.name)
                uapp += rec.name + ', '
            self.user_approvals = uapp

    @api.onchange('approve_process_by')
    def _approve_process_by(self):
        self.user_approvals = ""