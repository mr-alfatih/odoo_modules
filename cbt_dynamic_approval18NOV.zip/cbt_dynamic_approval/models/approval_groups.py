from odoo import api, fields, tools, models, _


class ApprovalInfo(models.Model):
    _name = 'approval.group'
    _description = "Approval Groups"

    name = fields.Char(string="Group Name")