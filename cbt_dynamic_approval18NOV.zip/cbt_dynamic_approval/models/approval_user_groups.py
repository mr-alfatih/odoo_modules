from odoo import api, fields, tools, models, _


class ApprovalInfo(models.Model):
    _name = 'approval.user.group'
    _description = "Approval User Groups"
    # _rec_name = 'group_id'

    name = fields.Char()
    company_id = fields.Many2one('res.company', 'Company', index=1, default=lambda self: self.env.company)
    group_id = fields.Many2one('approval.group', string="Groups")
    user_ids = fields.Many2many('res.users', string="Users")
    active = fields.Boolean(string="Status")